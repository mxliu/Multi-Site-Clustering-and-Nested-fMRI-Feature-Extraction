clc, clear all, close all,
% cd /Users/wangnan/Desktop/NAGFS-master/src/
% mex -largeArrayDims projsplx_c.c

% g=gpuDevice(1);

%core_number=4;            %想要调用的处理器个数
%parpool('local',core_number);

tempD2= [];
tempacc = [];
tempspe = [];
tempsen = [];
tempauc = [];
tempbau = [];
%% Setting graph data simulation parameters
%%

rsec=1; lsec=609;
data = csvread('basc064_correlation_new.csv',rsec,6,[rsec,6,lsec,2021]) ;
[r,ldata] = size(data);
m1 = csvread('basc064_correlation_new.csv',rsec, 2, [rsec,2,lsec,2]);
Labels = m1; %  Define labels
n=(-1+sqrt(1+8*ldata))/2 ;
zzzzzz=[];
Featurematrix = [];
%AA=zero(n,n)
AA=[];

for i = 1:r

   A=data(i,:);
   AA =row2triu(A);
  
  %  save AA AA; 
%    x2 = AA';
% % % % %  Featurematrix = [Featurematrix;x1];
%  x3 = triu(AA)+tril(x2,-1);
 x3 = triu(AA);
 x = x3(find(x3)); % Vectorize the triangle 
 x1 = x.';
 Featurematrix = [Featurematrix;x1];
%  X = data1;

 zzzzzz(i,:,:) = AA;  
end

 data=struct('Featurematrix', Featurematrix,'X',zzzzzz,'Labels',m1);
 data_class1 = data.Featurematrix((data.Labels ==1),:); % retrieve samples in class 1
 data_class2 =data.Featurematrix((data.Labels ==0),:);

%% Change 'displayResults' option for visualizing the learned network atlases and top selected features
%%
displayResults = 0; % input 1 if you want to visualize the estimated atlases and selected features at each run of the cross-validation algorithm


%%  Initialization ��ʼ��
%%
for Nf=10:100
    
Nf = Nf
c = cvpartition(size(data.Labels,1),'LeaveOut');
decision_score = zeros(size(data.Labels,1),1); % vector of decision values (indep.of treshold)
[sz1,sz2,sz3] = size(data.X);
ind_Nf = (zeros(size(data.Labels,1),Nf)); % store the indices of thr top discriminative features
dataFeatures = data.Featurematrix;
test_Labels_vector =zeros(size(data.Labels,1),1); % store ground truth in test order
accuracy = zeros(size(data.Labels,1),1) ; % store accuracy from each test
predicted_Labels = zeros(size(data.Labels,1),1); % vector to store predicted labels 


for m = 1 : c.NumObservations
    
    mm = num2str(m)
    
    % Create training and testing sets
    testIndex = c.test(m);
    trainIndex = c.training(m);
    train_Labels = data.Labels(trainIndex);
    train_data = data.X(trainIndex,:,:);
    
    
    test_Label = data.Labels(testIndex);
    test_data = data.X(testIndex,:,:);
    test_Labels_vector(m) = test_Label;
    
    %% NAGFS execution
    
    [~,~,topFeaturesind,D2,Dif] = NAGFS(train_data,train_Labels,Nf,displayResults); 
    
   
     tempD2=cat(1,D2,tempD2);
%      tempDif=cat(1,Dif,tempDif);
 
    
    %% Extract top Nf discriminative features
    
    train_set = zeros(length(train_Labels),length(dataFeatures));
    train_Nf = zeros(length(train_Labels),Nf);
    
    % Extract the top Nf discriminative training features
    
    train_set = zeros(length(train_Labels),length(dataFeatures));
    train_Nf = zeros(length(train_Labels),Nf);
    
    % Extract the top Nf discriminative training features
    
    for r = 1: (length(train_Labels))
        train_subject = squeeze(train_data(r,:,:));
        train = triu(train_subject);
        train_vect = [];
        
        for i = 1: sz3
            
            for j = (i+1): sz3
                train_vect = [train_vect,train(i,j)]; % Vectorize the upper triangular part of the training matrix
            end
            
        end
        
        train_set(r,:) = train_vect; % Matrix stacking all training subjects
        
        for h = 1: Nf
            l = topFeaturesind(h);
            train_Nf(r,h) = train_set(r,l); % Discriminative training matrix
        end
        
    end
    
    % Extract the same ranked features from the testing network
    
    test = triu(squeeze(test_data),1); % Upper triangular part of test matrix
    test_vect = [];
    for i = 1: sz3
        
        for j = (i+1): sz3
            test_vect = [test_vect,test(i,j)]; % Vectorize the upper triangular part of the test matrix
        end
        
    end
    
    test_Nf = [];
    for j = 1: Nf
        l = topFeaturesind(j);
        test_Nf = [test_Nf,test_vect(l)]; % Discriminative testing vector
    end
    

    % Classification using SVM classifier
%     [bestCVaccuracy,bestc,bestg]=SVMcgForClass(train_Labels,train_Nf);
    model = fitcsvm(train_Nf,train_Labels,'BoxConstraint',10,'KernelFunction','rbf','KernelScale',2^0.5*2); % Training the classifier using the training data
    [predict_Labels, accuracy, decision_values] = predict(model,test_Nf); % Testing the classfier on the left out data (hidden/test data)
    predicted_Labels(m) = predict_Labels;
    test_Labels_vector(m) = test_Label;
    ind_Nf(m,:) = topFeaturesind;
end
 auc = AUC(test_Labels_vector,predicted_Labels);
CM = confusionmat(test_Labels_vector,predicted_Labels); % Returns the confusion matrix CM determined by the known and predicted groups, respectively

True_Negative = CM(1,1);
True_Positive = CM(2,2);
False_Negative = CM(2,1);
False_Positive = CM(1,2);
Accuracy = (True_Positive + True_Negative)/(size(data.Labels,1)) * 100;
Sensitivity = (True_Positive)/(True_Positive + False_Negative) * 100;
Specificity = (True_Negative)/(True_Negative + False_Positive) * 100;
tempsen=cat(1,Sensitivity,tempsen);
tempspe=cat(1,Specificity,tempspe);
tempacc=cat(1,Accuracy,tempacc);
BAU=(Sensitivity + Specificity) / 2;

tempauc = cat(1,auc, tempauc);
tempbau = cat(1,BAU,tempbau);
save matPath.mat tempacc tempspe tempsen 
end
%% Display the average circular graph of top Nf discriminative features across all cross-validation runs


%% Display final results
%%

fprintf('\n')
disp( '                             Final results using leave-one-out cross-validation                         ');
fprintf('\n')
disp(['****************** Average accuracy = ' num2str(Accuracy) '% ******************']);
fprintf('\n')
disp(['****************** Average sensitivity = ' num2str(Sensitivity) '% ******************']);
fprintf('\n')
disp(['****************** Average Specificity = ' num2str(Specificity) '% ******************']);
