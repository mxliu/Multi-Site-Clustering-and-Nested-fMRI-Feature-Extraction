clc, clear all, close all,
% cd /Users/wangnan/Desktop/NAGFS-master/src/
% mex -largeArrayDims projsplx_c.c

% g=gpuDevice(1);

%core_number=4;            %想要调用的处理器个数
%parpool('local',core_number);


%% Setting graph data simulation parameters
%%

rsec=152; lsec=160;
train_data = csvread('basc064_correlation_new.csv',rsec,6,[rsec,6,lsec,2021]) ;
[r,ldata] = size(train_data);
m1 = csvread('basc064_correlation_new.csv',rsec, 2, [rsec,2,lsec,2]);
train_Labels = m1; %  Define labels

rsec=160; lsec=176;
test_data = csvread('basc064_correlation_new.csv',rsec, 6, [rsec,6,lsec,2021]);
m2 = csvread('basc064_correlation_new.csv',rsec, 2, [rsec,2,lsec,2]);
test_Labels = m2;


    model = fitcsvm(train_data,train_Labels,'BoxConstraint',10,'KernelFunction','rbf','KernelScale',2^0.5*2); % Training the classifier using the training data
    [predict_Labels, accuracy, decision_values] = predict(model,test_data); % Testing the classfier on the left out data (hidden/test data)
    
CM = confusionmat(test_Labels,predict_Labels); % Returns the confusion matrix CM determined by the known and predicted groups, respectively

True_Negative = CM(1,1);
True_Positive = CM(2,2);
False_Negative = CM(2,1);
False_Positive = CM(1,2);

Accuracy = ((True_Positive + True_Negative)/34) * 100;
Sensitivity = (True_Positive)/(True_Positive + False_Negative) * 100;
Specificity = (True_Negative)/(True_Negative + False_Positive) * 100;



%% Display final results
%%

fprintf('\n')
disp( '                             Final results using leave-one-out cross-validation                         ');
fprintf('\n')
disp(['****************** Average accuracy = ' num2str(Accuracy) '% ******************']);
fprintf('\n')
disp(['****************** Average sensitivity = ' num2str(Sensitivity) '% ******************']);
fprintf('\n')
disp(['****************** Average Specificity = ' num2str(Specificity) '% ******************']);
