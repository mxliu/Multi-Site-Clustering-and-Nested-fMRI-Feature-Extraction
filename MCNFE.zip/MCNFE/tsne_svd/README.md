## How to use?
1.  Clone this repository.
2.  How the Dataset and label should be arranged ?
    1. The script requires two inputs - `Data` and `Label`.
    2. Arrangement of  `Data`  - First column should be "label name" and rest of the columns should be "features".
    3. Arrangement of  `Label` - First column should be "label name" , which should be in the same order as `Data`'s label names.
    4. Each row in both `Data` and `Label` is a sample.
3. Replace the `Data` and `Label` in folder `inputs` directory with the same name.
4. Run the script `tsne_example.m`.
5. The code will generate both 2D and 3D t-sne plots.




