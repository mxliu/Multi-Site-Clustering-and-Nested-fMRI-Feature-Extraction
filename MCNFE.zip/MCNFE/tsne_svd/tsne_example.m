clc ; close all ; clear all ;

load('ac12new.mat');
load('label609svd.mat');

rng default % for reproducibility
Y = tsne(AC11,'Algorithm','barneshut','NumPCAComponents',50);

figure
gscatter(Y(:,1),Y(:,2),AC12)


rng default % for fair comparison
Y3 = tsne(AC11,'Algorithm','barneshut','NumPCAComponents',50,'NumDimensions',3);
figure
scatter3(Y3(:,1),Y3(:,2),Y3(:,3),15,AC12,'filled');
view(-93,14)