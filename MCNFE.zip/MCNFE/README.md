First，download toolboxs: 'src', 'snnf' , 'libsvm', 'circularGraph', FSLib_v6.1_2018,sklearn
then, add them to MATLAB by set path.


**************Function******************
NAGFS.m:  the method used on MICCAI, which uses the difference between subjects and HC.

NAGFSnodif.m: the method used on Medical image analysis, which directly uses the features between subjects and HC.

NAGFS1svd.m:  this method uses SVD only once.



***************Adjusting parameters*******************

Nf can be adjusted for different sites;

SIMLR can use different numbers of clusters;

D2 can be adjusted for different sites; (D2=D2(randperm(numel(D2),110));)

